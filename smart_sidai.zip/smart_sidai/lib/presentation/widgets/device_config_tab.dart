import 'package:flutter/material.dart';
import '../../data/models/device_model.dart';
import '../../services/firebase/firebase_routes.dart';
import '../../core/constants/theme_constants.dart';
import 'config_sections/temperature_thresholds_section.dart';
import 'config_sections/humidity_thresholds_section.dart';
import 'config_sections/system_settings_section.dart';
import 'config_sections/pir_motion_settings_section.dart';
import 'config_sections/advanced_settings_section.dart';

class DeviceConfigTab extends StatefulWidget {
  final DeviceModel device;

  const DeviceConfigTab({
    super.key,
    required this.device,
  });

  @override
  State<DeviceConfigTab> createState() => _DeviceConfigTabState();
}

class _DeviceConfigTabState extends State<DeviceConfigTab> {
  // Local state for configuration values
  late double _tempMinThreshold;
  late double _tempMaxThreshold;
  late double _humidityMinThreshold;
  late double _humidityMaxThreshold;
  late int _motorTimeout;
  late int _sensorReadInterval;
  late int _distanceExtended;
  late int _distanceRetracted;
  late bool _useCustomThresholds;
  late bool _autoMode;
  late bool _enablePirControl;
  late bool _retractOnUserPresent;
  late int _pirRetractDelay;

  @override
  void initState() {
    super.initState();
    _initializeConfigValues();
    _loadLatestConfigFromFirebase();
  }

  void _initializeConfigValues() {
    final config = widget.device.deviceConfig;
    _tempMinThreshold = config.tempMinThreshold;
    _tempMaxThreshold = config.tempMaxThreshold;
    _humidityMinThreshold = config.humidityMinThreshold;
    _humidityMaxThreshold = config.humidityMaxThreshold;
    _motorTimeout = config.motorTimeout;
    _sensorReadInterval = config.sensorReadInterval;
    _distanceExtended = config.distanceExtended;
    _distanceRetracted = config.distanceRetracted;
    _useCustomThresholds = config.useCustomThresholds;
    _autoMode = config.autoMode;
    _enablePirControl = config.enablePirControl;
    _retractOnUserPresent = config.retractOnUserPresent;
    _pirRetractDelay = config.pirRetractDelay;
  }

  Future<void> _loadLatestConfigFromFirebase() async {
    try {
      final deviceData = await FirebaseService.getDeviceById(widget.device.id);
      if (deviceData != null && mounted) {
        setState(() {
          final config = deviceData.deviceConfig;
          _tempMinThreshold = config.tempMinThreshold;
          _tempMaxThreshold = config.tempMaxThreshold;
          _humidityMinThreshold = config.humidityMinThreshold;
          _humidityMaxThreshold = config.humidityMaxThreshold;
          _motorTimeout = config.motorTimeout;
          _sensorReadInterval = config.sensorReadInterval;
          _distanceExtended = config.distanceExtended;
          _distanceRetracted = config.distanceRetracted;
          _useCustomThresholds = config.useCustomThresholds;
          _autoMode = config.autoMode; // Always get latest autoMode from Firebase
          _enablePirControl = config.enablePirControl;
          _retractOnUserPresent = config.retractOnUserPresent;
          _pirRetractDelay = config.pirRetractDelay;
        });
      }
    } catch (e) {
      // Handle error silently, keep using cached values as fallback
      print('Failed to load latest config from Firebase: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TemperatureThresholdsSection(
              tempMinThreshold: _tempMinThreshold,
              tempMaxThreshold: _tempMaxThreshold,
              onTempMinChanged: (value) {
                setState(() {
                  _tempMinThreshold = value;
                });
                _updateConfig('tempMinThreshold', value);
              },
              onTempMaxChanged: (value) {
                setState(() {
                  _tempMaxThreshold = value;
                });
                _updateConfig('tempMaxThreshold', value);
              },
            ),
            const SizedBox(height: 24),
            HumidityThresholdsSection(
              humidityMinThreshold: _humidityMinThreshold,
              humidityMaxThreshold: _humidityMaxThreshold,
              onHumidityMinChanged: (value) {
                setState(() {
                  _humidityMinThreshold = value;
                });
                _updateConfig('humidityMinThreshold', value);
              },
              onHumidityMaxChanged: (value) {
                setState(() {
                  _humidityMaxThreshold = value;
                });
                _updateConfig('humidityMaxThreshold', value);
              },
            ),
            const SizedBox(height: 24),
            SystemSettingsSection(
              motorTimeout: _motorTimeout,
              sensorReadInterval: _sensorReadInterval,
              distanceExtended: _distanceExtended,
              distanceRetracted: _distanceRetracted,
              device: widget.device,
              onMotorTimeoutChanged: (value) {
                setState(() {
                  _motorTimeout = value;
                });
                _updateConfig('motorTimeout', value);
              },
              onSensorReadIntervalChanged: (value) {
                setState(() {
                  _sensorReadInterval = value;
                });
                _updateConfig('sensorReadInterval', value);
              },
              onDistanceExtendedChanged: (value) {
                setState(() {
                  _distanceExtended = value;
                });
                _updateConfig('distanceExtended', value);
              },
              onDistanceRetractedChanged: (value) {
                setState(() {
                  _distanceRetracted = value;
                });
                _updateConfig('distanceRetracted', value);
              },
            ),
            const SizedBox(height: 24),
            PirMotionSettingsSection(
              enablePirControl: _enablePirControl,
              retractOnUserPresent: _retractOnUserPresent,
              pirRetractDelay: _pirRetractDelay,
              onEnablePirControlChanged: (value) {
                setState(() {
                  _enablePirControl = value;
                });
                _updateConfig('enablePirControl', value);
              },
              onRetractOnUserPresentChanged: (value) {
                setState(() {
                  _retractOnUserPresent = value;
                });
                _updateConfig('retractOnUserPresent', value);
              },
              onPirRetractDelayChanged: (value) {
                setState(() {
                  _pirRetractDelay = value;
                });
                _updateConfig('pirRetractDelay', value);
              },
            ),
            const SizedBox(height: 24),
            AdvancedSettingsSection(
              useCustomThresholds: _useCustomThresholds,
              autoMode: _autoMode,
              onUseCustomThresholdsChanged: (value) {
                setState(() {
                  _useCustomThresholds = value;
                });
                _updateConfig('useCustomThresholds', value);
              },
              onAutoModeChanged: (value) {
                _updateAutoMode(value);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _updateAutoMode(bool value) async {
    try {
      // Update Firebase first
      await FirebaseService.updateDeviceConfig(widget.device.id, {'autoMode': value});
      
      // Then refresh the state from Firebase to ensure consistency
      await _loadLatestConfigFromFirebase();
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(value ? 'Auto mode enabled' : 'Manual mode enabled'),
            backgroundColor: ThemeConstants.successColor,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update auto mode: $e'),
            backgroundColor: ThemeConstants.errorColor,
          ),
        );
      }
    }
  }

  Future<void> _updateConfig(String key, dynamic value) async {
    try {
      await FirebaseService.updateDeviceConfig(widget.device.id, {key: value});
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Configuration updated successfully'),
            backgroundColor: ThemeConstants.successColor,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update configuration: $e'),
            backgroundColor: ThemeConstants.errorColor,
          ),
        );
      }
    }
  }
} 