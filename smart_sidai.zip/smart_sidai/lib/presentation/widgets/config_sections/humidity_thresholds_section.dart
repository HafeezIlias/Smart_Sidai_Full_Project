import 'package:flutter/material.dart';
import 'config_section_base.dart';
import 'threshold_slider.dart';

class HumidityThresholdsSection extends StatelessWidget {
  final double humidityMinThreshold;
  final double humidityMaxThreshold;
  final Function(double) onHumidityMinChanged;
  final Function(double) onHumidityMaxChanged;

  const HumidityThresholdsSection({
    super.key,
    required this.humidityMinThreshold,
    required this.humidityMaxThreshold,
    required this.onHumidityMinChanged,
    required this.onHumidityMaxChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ConfigSection(
      title: 'Humidity Thresholds',
      icon: Icons.water_drop,
      children: [
        ThresholdSlider(
          label: 'Min Humidity',
          value: humidityMinThreshold,
          min: 0.0,
          max: 100.0,
          onChanged: onHumidityMinChanged,
          unit: '%',
        ),
        const SizedBox(height: 16),
        ThresholdSlider(
          label: 'Max Humidity',
          value: humidityMaxThreshold,
          min: 0.0,
          max: 100.0,
          onChanged: onHumidityMaxChanged,
          unit: '%',
        ),
      ],
    );
  }
} 