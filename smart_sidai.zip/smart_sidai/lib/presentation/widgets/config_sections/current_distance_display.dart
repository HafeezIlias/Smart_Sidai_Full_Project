import 'package:flutter/material.dart';
import '../../../data/models/device_model.dart';
import '../../../data/models/sensor_data.dart';
import '../../../services/firebase/firebase_routes.dart';

class CurrentDistanceDisplay extends StatelessWidget {
  final DeviceModel device;
  final int distanceExtended;
  final int distanceRetracted;

  const CurrentDistanceDisplay({
    super.key,
    required this.device,
    required this.distanceExtended,
    required this.distanceRetracted,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.blue.withOpacity(0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.straighten,
                color: Colors.blue[700],
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Real-time Distance',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.blue[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          StreamBuilder<List<SensorData>>(
            stream: FirebaseService.getSensorDataStream(device.id, limit: 1),
            builder: (context, snapshot) {
              if (snapshot.hasData && snapshot.data!.isNotEmpty) {
                final latestSensorData = snapshot.data!.first;
                final currentDistance = latestSensorData.distance;
                final extendedDiff = (currentDistance - distanceExtended).abs();
                final retractedDiff = (currentDistance - distanceRetracted).abs();
                
                return Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Current Reading:',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[700],
                              ),
                            ),
                            Text(
                              'Updated: ${_formatTimestamp(latestSensorData.timestamp)}',
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.grey[500],
                              ),
                            ),
                          ],
                        ),
                        Text(
                          '${currentDistance.toStringAsFixed(1)} cm',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Extended Target:',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                        Text(
                          '$distanceExtended cm (±${extendedDiff.toStringAsFixed(1)})',
                          style: TextStyle(
                            fontSize: 12,
                            color: extendedDiff <= 2 ? Colors.green : Colors.orange,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Retracted Target:',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                        Text(
                          '$distanceRetracted cm (±${retractedDiff.toStringAsFixed(1)})',
                          style: TextStyle(
                            fontSize: 12,
                            color: retractedDiff <= 2 ? Colors.green : Colors.orange,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getCalibrationStatusColor(extendedDiff, retractedDiff),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _getCalibrationStatusText(currentDistance, extendedDiff, retractedDiff),
                        style: const TextStyle(
                          fontSize: 11,
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                );
              } else if (snapshot.connectionState == ConnectionState.waiting) {
                return const Row(
                  children: [
                    SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                    SizedBox(width: 8),
                    Text('Loading distance data...'),
                  ],
                );
              } else if (snapshot.hasError) {
                return Column(
                  children: [
                    Icon(
                      Icons.error_outline,
                      color: Colors.red[400],
                      size: 24,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Error loading distance data',
                      style: TextStyle(
                        color: Colors.red[400],
                        fontSize: 12,
                      ),
                    ),
                  ],
                );
              } else {
                return Column(
                  children: [
                    Icon(
                      Icons.sensors_off,
                      color: Colors.grey[400],
                      size: 24,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'No distance data available',
                      style: TextStyle(
                        color: Colors.grey,
                        fontStyle: FontStyle.italic,
                        fontSize: 12,
                      ),
                    ),
                  ],
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Color _getCalibrationStatusColor(double extendedDiff, double retractedDiff) {
    if (extendedDiff <= 2 || retractedDiff <= 2) {
      return Colors.green;
    } else if (extendedDiff <= 5 || retractedDiff <= 5) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }

  String _getCalibrationStatusText(double currentDistance, double extendedDiff, double retractedDiff) {
    if (extendedDiff <= retractedDiff) {
      if (extendedDiff <= 2) {
        return '✓ Close to Extended position';
      } else if (extendedDiff <= 5) {
        return '⚠ Near Extended position';
      } else {
        return '✗ Far from Extended position';
      }
    } else {
      if (retractedDiff <= 2) {
        return '✓ Close to Retracted position';
      } else if (retractedDiff <= 5) {
        return '⚠ Near Retracted position';
      } else {
        return '✗ Far from Retracted position';
      }
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);
    
    if (difference.inSeconds < 60) {
      return '${difference.inSeconds}s ago';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      // For older data, show actual date
      return '${timestamp.day}/${timestamp.month}/${timestamp.year}';
    }
  }
} 