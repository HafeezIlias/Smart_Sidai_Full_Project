import 'package:flutter/material.dart';
import 'config_section_base.dart';
import 'threshold_slider.dart';

class TemperatureThresholdsSection extends StatelessWidget {
  final double tempMinThreshold;
  final double tempMaxThreshold;
  final Function(double) onTempMinChanged;
  final Function(double) onTempMaxChanged;

  const TemperatureThresholdsSection({
    super.key,
    required this.tempMinThreshold,
    required this.tempMaxThreshold,
    required this.onTempMinChanged,
    required this.onTempMaxChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ConfigSection(
      title: 'Temperature Thresholds',
      icon: Icons.thermostat,
      children: [
        ThresholdSlider(
          label: 'Min Temperature',
          value: tempMinThreshold,
          min: 0.0,
          max: 50.0,
          onChanged: onTempMinChanged,
          unit: '°C',
        ),
        const SizedBox(height: 16),
        ThresholdSlider(
          label: 'Max Temperature',
          value: tempMaxThreshold,
          min: 0.0,
          max: 50.0,
          onChanged: onTempMaxChanged,
          unit: '°C',
        ),
      ],
    );
  }
} 