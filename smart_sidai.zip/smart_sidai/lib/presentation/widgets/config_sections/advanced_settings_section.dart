import 'package:flutter/material.dart';
import 'config_section_base.dart';
import 'switch_tile.dart';

class AdvancedSettingsSection extends StatelessWidget {
  final bool useCustomThresholds;
  final bool autoMode;
  final Function(bool) onUseCustomThresholdsChanged;
  final Function(bool) onAutoModeChanged;

  const AdvancedSettingsSection({
    super.key,
    required this.useCustomThresholds,
    required this.autoMode,
    required this.onUseCustomThresholdsChanged,
    required this.onAutoModeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ConfigSection(
      title: 'Advanced Settings',
      icon: Icons.toggle_on,
      children: [
        SwitchTile(
          title: 'Use Custom Thresholds',
          subtitle: 'Enable custom temperature and humidity thresholds',
          value: useCustomThresholds,
          onChanged: onUseCustomThresholdsChanged,
        ),
        const SizedBox(height: 8),
        SwitchTile(
          title: 'Auto Mode',
          subtitle: 'Automatically respond to weather conditions',
          value: autoMode,
          onChanged: onAutoModeChanged,
        ),
      ],
    );
  }
} 