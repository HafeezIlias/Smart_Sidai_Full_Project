import 'package:flutter/material.dart';
import '../../../data/models/device_model.dart';
import 'config_section_base.dart';
import 'number_input.dart';
import 'current_distance_display.dart';

class SystemSettingsSection extends StatelessWidget {
  final int motorTimeout;
  final int sensorReadInterval;
  final int distanceExtended;
  final int distanceRetracted;
  final DeviceModel device;
  final Function(int) onMotorTimeoutChanged;
  final Function(int) onSensorReadIntervalChanged;
  final Function(int) onDistanceExtendedChanged;
  final Function(int) onDistanceRetractedChanged;

  const SystemSettingsSection({
    super.key,
    required this.motorTimeout,
    required this.sensorReadInterval,
    required this.distanceExtended,
    required this.distanceRetracted,
    required this.device,
    required this.onMotorTimeoutChanged,
    required this.onSensorReadIntervalChanged,
    required this.onDistanceExtendedChanged,
    required this.onDistanceRetractedChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ConfigSection(
      title: 'System Settings',
      icon: Icons.settings,
      children: [
        NumberInput(
          label: 'Motor Timeout',
          value: motorTimeout,
          onChanged: onMotorTimeoutChanged,
          unit: 'ms',
          min: 1000,
          max: 120000,
        ),
        const SizedBox(height: 16),
        NumberInput(
          label: 'Sensor Read Interval',
          value: sensorReadInterval,
          onChanged: onSensorReadIntervalChanged,
          unit: 'ms',
          min: 500,
          max: 10000,
        ),
        const SizedBox(height: 16),
        NumberInput(
          label: 'Distance Extended',
          value: distanceExtended,
          onChanged: onDistanceExtendedChanged,
          unit: 'cm',
          min: 10,
          max: 100,
        ),
        const SizedBox(height: 16),
        NumberInput(
          label: 'Distance Retracted',
          value: distanceRetracted,
          onChanged: onDistanceRetractedChanged,
          unit: 'cm',
          min: 5,
          max: 50,
        ),
        const SizedBox(height: 16),
        CurrentDistanceDisplay(
          device: device,
          distanceExtended: distanceExtended,
          distanceRetracted: distanceRetracted,
        ),
      ],
    );
  }
} 