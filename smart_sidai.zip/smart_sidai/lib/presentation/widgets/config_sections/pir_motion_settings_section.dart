import 'package:flutter/material.dart';
import 'config_section_base.dart';
import 'switch_tile.dart';
import 'number_input.dart';

class PirMotionSettingsSection extends StatelessWidget {
  final bool enablePirControl;
  final bool retractOnUserPresent;
  final int pirRetractDelay;
  final Function(bool) onEnablePirControlChanged;
  final Function(bool) onRetractOnUserPresentChanged;
  final Function(int) onPirRetractDelayChanged;

  const PirMotionSettingsSection({
    super.key,
    required this.enablePirControl,
    required this.retractOnUserPresent,
    required this.pirRetractDelay,
    required this.onEnablePirControlChanged,
    required this.onRetractOnUserPresentChanged,
    required this.onPirRetractDelayChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ConfigSection(
      title: 'PIR Motion Settings',
      icon: Icons.motion_photos_on,
      children: [
        SwitchTile(
          title: 'Enable PIR Control',
          subtitle: 'Use PIR sensor to detect user presence',
          value: enablePirControl,
          onChanged: onEnablePirControlChanged,
        ),
        const SizedBox(height: 8),
        SwitchTile(
          title: 'Retract on User Present',
          subtitle: 'Retract the device when user is detected nearby',
          value: retractOnUserPresent,
          onChanged: onRetractOnUserPresentChanged,
        ),
        const SizedBox(height: 16),
        NumberInput(
          label: 'PIR Retract Delay',
          value: pirRetractDelay,
          onChanged: onPirRetractDelayChanged,
          unit: 'sec',
          min: 0,
          max: 60,
        ),
      ],
    );
  }
} 