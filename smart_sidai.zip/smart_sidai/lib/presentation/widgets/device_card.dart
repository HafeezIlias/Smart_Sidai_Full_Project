import 'package:flutter/material.dart';
import '../../data/models/device_model.dart';
import '../../core/constants/theme_constants.dart';
import '../../data/models/device_status.dart';

class DeviceCard extends StatelessWidget {
  final DeviceModel device;
  final VoidCallback onTap;
  final Function(bool) onStatusChanged;

  const DeviceCard({
    super.key,
    required this.device,
    required this.onTap,
    required this.onStatusChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      margin: EdgeInsets.zero,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _buildStatusIndicator(),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          device.name,
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        Text(
                          device.location,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Last updated: ${_formatLastUpdate(device.lastUpdate)}',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.grey[500],
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _buildStatusSwitch(),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _buildSensorReading(
                      Icons.thermostat,
                      '${device.sensorData.temperature.toStringAsFixed(1)}°C',
                      'Temperature',
                    ),
                  ),
                  Expanded(
                    child: _buildSensorReading(
                      Icons.water_drop,
                      '${device.sensorData.humidity.toStringAsFixed(1)}%',
                      'Humidity',
                    ),
                  ),
                  Expanded(
                    child: _buildSensorReading(
                      device.sensorData.rainDetected ? Icons.umbrella : Icons.wb_sunny,
                      device.sensorData.rainDetected ? 'Rain' : 'Clear',
                      'Weather',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusIndicator() {
    Color color = _getStatusColor();
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Icon(
        _getStatusIcon(),
        color: color,
        size: 24,
      ),
    );
  }

  Widget _buildStatusSwitch() {
    final bool isExtended = _isRequestedExtended();
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Switch(
          value: isExtended,
          onChanged: (value) {
            onStatusChanged(value);
          },
          activeColor: ThemeConstants.successColor,
          activeTrackColor: ThemeConstants.successColor.withOpacity(0.3),
        ),
        const SizedBox(height: 4),
        Text(
          isExtended ? 'Extended' : 'Retracted',
          style: TextStyle(
            fontSize: 12,
            color: isExtended ? ThemeConstants.successColor : Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  bool _isRequestedExtended() {
    final requestedState = device.deviceConfig.requestedState.toUpperCase();
    
    // If requestedState is explicitly set, use that
    if (requestedState == 'EXTENDED') return true;
    if (requestedState == 'RETRACTED') return false;
    
    // If requestedState is "none" or empty, fall back to actual device status
    if (requestedState == 'NONE' || requestedState == '') {
      return device.status == DeviceStatus.extended;
    }
    
    // Default to retracted for other states
    return false;
  }

  Widget _buildSensorReading(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, size: 20, color: Colors.grey[600]),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Color _getStatusColor() {
    switch (device.status) {
      case DeviceStatus.extended:
        return ThemeConstants.successColor;
      case DeviceStatus.retracted:
        return ThemeConstants.infoColor;
      case DeviceStatus.moving:
        return ThemeConstants.warningColor;
      case DeviceStatus.error:
        return ThemeConstants.errorColor;
      case DeviceStatus.offline:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon() {
    switch (device.status) {
      case DeviceStatus.extended:
        return Icons.unfold_more;
      case DeviceStatus.retracted:
        return Icons.unfold_less;
      case DeviceStatus.moving:
        return Icons.sync;
      case DeviceStatus.error:
        return Icons.error;
      case DeviceStatus.offline:
        return Icons.wifi_off;
    }
  }

  String _formatLastUpdate(DateTime lastUpdate) {
    final now = DateTime.now();
    final difference = now.difference(lastUpdate);

    if (difference.inSeconds < 60) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return '${lastUpdate.day}/${lastUpdate.month}/${lastUpdate.year}';
    }
  }
} 