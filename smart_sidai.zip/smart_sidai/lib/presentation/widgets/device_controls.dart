import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../data/models/device_model.dart';
import '../providers/device_provider.dart';
import '../../data/models/device_status.dart';
import '../../services/firebase/firebase_routes.dart';

class DeviceControls extends StatefulWidget {
  final DeviceModel device;

  const DeviceControls({
    super.key,
    required this.device,
  });

  @override
  State<DeviceControls> createState() => _DeviceControlsState();
}

class _DeviceControlsState extends State<DeviceControls> {
  bool _isLoading = false;
  bool _isAutoMode = false;
  bool _enablePirControl = false;
  bool _retractOnUserPresent = false;
  int _pirRetractDelay = 0;

  @override
  void initState() {
    super.initState();
    _loadAutoModeStatus();
    _loadPirSettings();
  }

  Future<void> _loadAutoModeStatus() async {
    try {
      final deviceData = await FirebaseService.getDeviceById(widget.device.id);
      if (deviceData != null && mounted) {
        setState(() {
          // Get autoMode from config (the source of truth)
          _isAutoMode = deviceData.deviceConfig.autoMode;
        });
      }
    } catch (e) {
      // Handle error silently
      print('Failed to load auto mode status: $e');
    }
  }

  Future<void> _loadPirSettings() async {
    try {
      final deviceData = await FirebaseService.getDeviceById(widget.device.id);
      if (deviceData != null && mounted) {
        setState(() {
          _enablePirControl = deviceData.deviceConfig.enablePirControl;
          _retractOnUserPresent = deviceData.deviceConfig.retractOnUserPresent;
          _pirRetractDelay = deviceData.deviceConfig.pirRetractDelay;
        });
      }
    } catch (e) {
      // Handle error silently
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Device Controls',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            
            // Status indicator
            Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: widget.device.isOnline ? Colors.green : Colors.red,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  widget.device.isOnline ? 'Online' : 'Offline',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const Spacer(),
                Text(
                  widget.device.status.displayName,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: _getStatusColor(widget.device.status),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Auto/Manual Mode Toggle
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Icon(
                        _isAutoMode ? Icons.auto_mode : Icons.touch_app,
                        color: _isAutoMode ? Colors.green : Colors.blue,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _isAutoMode ? 'Auto Mode' : 'Manual Mode',
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Switch(
                        value: _isAutoMode,
                        onChanged: widget.device.isOnline ? _toggleAutoMode : null,
                        activeColor: Colors.green,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      _isAutoMode 
                        ? 'Operates automatically based on sensors'
                        : 'Controlled manually via app',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.grey[600],
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 12),
            
            // PIR Motion Control Section
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.motion_photos_on,
                        color: Colors.blue.shade700,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'PIR Motion Control',
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: Colors.blue.shade700,
                          ),
                        ),
                      ),
                      Switch(
                        value: _enablePirControl,
                        onChanged: widget.device.isOnline ? _togglePirControl : null,
                        activeColor: Colors.blue.shade600,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _enablePirControl
                        ? 'PIR sensor will detect user presence'
                        : 'PIR motion detection is disabled',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                      fontSize: 11,
                    ),
                  ),
                  
                  // User present controls (only show when PIR is enabled)
                  if (_enablePirControl) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blue.shade100),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'When User is Present:',
                            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: Colors.blue.shade800,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: Row(
                                  children: [
                                    Radio<bool>(
                                      value: false,
                                      groupValue: _retractOnUserPresent,
                                      onChanged: widget.device.isOnline 
                                          ? (value) => _updateRetractSetting(value ?? false)
                                          : null,
                                      activeColor: Colors.blue.shade600,
                                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        'Stay Extended',
                                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Row(
                                  children: [
                                    Radio<bool>(
                                      value: true,
                                      groupValue: _retractOnUserPresent,
                                      onChanged: widget.device.isOnline 
                                          ? (value) => _updateRetractSetting(value ?? true)
                                          : null,
                                      activeColor: Colors.blue.shade600,
                                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    ),
                                    const SizedBox(width: 4),
                                    Expanded(
                                      child: Text(
                                        'Retract',
                                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          
                          // Delay setting (only show when retract is selected)
                          if (_retractOnUserPresent) ...[
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Text(
                                  'Delay:',
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 12,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  width: 60,
                                  height: 28,
                                  child: TextFormField(
                                    initialValue: _pirRetractDelay.toString(),
                                    keyboardType: TextInputType.number,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(fontSize: 12),
                                    decoration: InputDecoration(
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(6),
                                        borderSide: BorderSide(color: Colors.blue.shade300),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(6),
                                        borderSide: BorderSide(color: Colors.blue.shade300),
                                      ),
                                    ),
                                    onChanged: (value) {
                                      final delay = int.tryParse(value) ?? 0;
                                      if (delay >= 0 && delay <= 60) {
                                        _updateRetractDelay(delay);
                                      }
                                    },
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  'sec',
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    fontSize: 12,
                                    color: Colors.grey[600],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
            
            const SizedBox(height: 12),
            
            // Control buttons
            if (widget.device.isOnline) ...[
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _isExtendButtonDisabled() ? null : () => _sendCommand('extend'),
                      icon: _isLoading 
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.expand_more, size: 18),
                      label: const Text('Extend', style: TextStyle(fontSize: 14)),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _isRetractButtonDisabled() ? null : () => _sendCommand('retract'),
                      icon: _isLoading 
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.expand_less, size: 18),
                      label: const Text('Retract', style: TextStyle(fontSize: 14)),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      ),
                    ),
                  ),
                ],
              ),
              
              if (_isAutoMode) ...[
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.green.shade200),
                  ),
                  child: Text(
                    'Manual controls disabled in Auto Mode',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.green.shade700,
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ] else ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'Device is offline. Controls are not available.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            ],
            
            const SizedBox(height: 12),
            
            // Last update info
            Text(
              'Last updated: ${_formatDateTime(widget.device.lastUpdate)}',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey,
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _togglePirControl(bool value) async {
    setState(() {
      _isLoading = true;
    });

    try {
      await FirebaseService.updateDeviceConfig(widget.device.id, {
        'enablePirControl': value,
      });
      
      setState(() {
        _enablePirControl = value;
        if (!value) {
          // Reset other PIR settings when disabled
          _retractOnUserPresent = false;
          _pirRetractDelay = 0;
        }
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(value ? 'PIR control enabled' : 'PIR control disabled'),
            backgroundColor: Colors.blue,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update PIR control: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _updateRetractSetting(bool value) async {
    try {
      await FirebaseService.updateDeviceConfig(widget.device.id, {
        'retractOnUserPresent': value,
      });
      
      setState(() {
        _retractOnUserPresent = value;
        if (!value) {
          _pirRetractDelay = 0; // Reset delay when not retracting
        }
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(value 
                ? 'Device will retract when user is present' 
                : 'Device will stay extended when user is present'),
            backgroundColor: Colors.blue,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update setting: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _updateRetractDelay(int delay) async {
    try {
      await FirebaseService.updateDeviceConfig(widget.device.id, {
        'pirRetractDelay': delay,
      });
      
      setState(() {
        _pirRetractDelay = delay;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update delay: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _toggleAutoMode(bool value) async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Update only config autoMode (status should reflect actual device state)
      await FirebaseService.updateDeviceConfig(widget.device.id, {
        'autoMode': value,
      });
      
      // Refresh the state from Firebase to ensure consistency
      await _loadAutoModeStatus();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(value ? 'Auto mode enabled' : 'Manual mode enabled'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update mode: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _sendCommand(String command) async {
    if (_isLoading || _isAutoMode) return;
    
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<DeviceProvider>(context, listen: false)
          .sendCommand(widget.device.id, command);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send command: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  bool _isExtendButtonDisabled() {
    if (_isLoading || _isAutoMode) return true;
    
    final requestedState = widget.device.deviceConfig.requestedState.toUpperCase();
    
    // Disable extend button if already requested to extend
    if (requestedState == 'EXTENDED') return true;
    
    // If "none" or other states, check actual device status
    if (requestedState == 'NONE' || requestedState == '') {
      return widget.device.status == DeviceStatus.extended;
    }
    
    return false;
  }

  bool _isRetractButtonDisabled() {
    if (_isLoading || _isAutoMode) return true;
    
    final requestedState = widget.device.deviceConfig.requestedState.toUpperCase();
    
    // Disable retract button if already requested to retract
    if (requestedState == 'RETRACTED') return true;
    
    // If "none" or other states, check actual device status
    if (requestedState == 'NONE' || requestedState == '') {
      return widget.device.status == DeviceStatus.retracted;
    }
    
    return false;
  }

  Color _getStatusColor(DeviceStatus status) {
    switch (status) {
      case DeviceStatus.extended:
        return Colors.blue;
      case DeviceStatus.retracted:
        return Colors.green;
      case DeviceStatus.moving:
        return Colors.orange;
      case DeviceStatus.error:
        return Colors.red;
      case DeviceStatus.offline:
        return Colors.grey;
    }
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }
} 