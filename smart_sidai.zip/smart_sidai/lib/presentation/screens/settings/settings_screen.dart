import 'package:flutter/material.dart';
import '../../../core/constants/theme_constants.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        centerTitle: true,
      ),
      body: _buildSettingsContent(context),
    );
  }

  Widget _buildSettingsContent(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildSection(
          context,
          title: 'App Settings',
          children: [
            _buildSettingsTile(
              context,
              icon: Icons.dark_mode,
              title: 'Dark Mode',
              trailing: Switch(
                value: false,
                onChanged: (value) {
                  // TODO: Implement dark mode toggle
                },
              ),
            ),
            _buildSettingsTile(
              context,
              icon: Icons.language,
              title: 'Language',
              subtitle: 'English',
              onTap: () {
                // TODO: Implement language selection
              },
            ),
          ],
        ),
        const SizedBox(height: 24),
        _buildSection(
          context,
          title: 'Device Settings',
          children: [
            _buildSettingsTile(
              context,
              icon: Icons.bluetooth,
              title: 'Bluetooth',
              trailing: Switch(
                value: true,
                onChanged: (value) {
                  // TODO: Implement bluetooth toggle
                },
              ),
            ),
            _buildSettingsTile(
              context,
              icon: Icons.wifi,
              title: 'WiFi',
              trailing: Switch(
                value: true,
                onChanged: (value) {
                  // TODO: Implement wifi toggle
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _buildSection(
          context,
          title: 'About',
          children: [
            _buildSettingsTile(
              context,
              icon: Icons.info,
              title: 'Version',
              subtitle: '1.0.0',
            ),
            _buildSettingsTile(
              context,
              icon: Icons.description,
              title: 'Terms of Service',
              onTap: () {
                // TODO: Show terms of service
              },
            ),
            _buildSettingsTile(
              context,
              icon: Icons.privacy_tip,
              title: 'Privacy Policy',
              onTap: () {
                // TODO: Show privacy policy
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSection(
    BuildContext context, {
    required String title,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            title,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: children,
          ),
        ),
      ],
    );
  }

  Widget _buildSettingsTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    String? subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: ThemeConstants.primaryColor),
      title: Text(title),
      subtitle: subtitle != null ? Text(subtitle) : null,
      trailing: trailing ?? (onTap != null ? const Icon(Icons.chevron_right) : null),
      onTap: onTap,
    );
  }
} 