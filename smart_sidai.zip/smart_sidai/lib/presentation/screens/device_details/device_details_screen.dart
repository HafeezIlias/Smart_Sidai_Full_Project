import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import '../../../data/models/device_model.dart';
import '../../../data/models/sensor_data.dart';
import '../../../core/constants/theme_constants.dart';
import '../../../data/models/device_status.dart';
import '../../../core/utils/error_handler.dart';
import '../../../services/firebase/firebase_routes.dart';
import '../../providers/device_provider.dart';
import '../../widgets/sensor_chart.dart';
import '../../widgets/device_controls.dart';
import '../../widgets/alert_list.dart';
import '../../widgets/device_config_tab.dart';

class DeviceDetailsScreen extends StatefulWidget {
  final DeviceModel device;

  const DeviceDetailsScreen({
    super.key,
    required this.device,
  });

  @override
  State<DeviceDetailsScreen> createState() => _DeviceDetailsScreenState();
}

class _DeviceDetailsScreenState extends State<DeviceDetailsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  SensorData? _latestSensorData;
  StreamSubscription<List<SensorData>>? _sensorDataSubscription;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _setupRealTimeSensorListener();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _sensorDataSubscription?.cancel();
    super.dispose();
  }

  void _setupRealTimeSensorListener() {
    _sensorDataSubscription = FirebaseService.getSensorDataStream(widget.device.id, limit: 1)
        .listen(
      (sensorDataList) {
        if (mounted && sensorDataList.isNotEmpty) {
          setState(() {
            _latestSensorData = sensorDataList.first;
          });
        }
      },
      onError: (error) {
        // Handle error silently for background refresh
        print('Error listening to sensor data: $error');
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          _buildAppBar(context),
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildDeviceHeader(),
                _buildTabBar(),
                _buildTabBarView(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget _buildAppBar(BuildContext context) {
  return SliverAppBar(
    pinned: true,
    backgroundColor: ThemeConstants.primaryColor,
    title: Text(
      widget.device.name,
      style: const TextStyle(
        fontSize: 18,
        color: Colors.white,
        fontWeight: FontWeight.bold,
      ),
    ),
    actions: [
      IconButton(
        icon: const Icon(Icons.edit, color: Colors.white),
        onPressed: () => _showEditDeviceNameDialog(context),
      ),
      Container(
        margin: const EdgeInsets.only(right: 16),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: _getStatusColor().withOpacity(0.2),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: Colors.white.withOpacity(0.3)),
        ),
        child: Text(
          widget.device.status.displayName,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 12,
          ),
        ),
      ),
    ],
  );
}

  Widget _buildDeviceHeader() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Location',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    Text(
                      widget.device.location,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: widget.device.isOnline
                      ? ThemeConstants.successColor.withOpacity(0.1)
                      : ThemeConstants.errorColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: widget.device.isOnline
                            ? ThemeConstants.successColor
                            : ThemeConstants.errorColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.device.isOnline ? 'Online' : 'Offline',
                      style: TextStyle(
                        color: widget.device.isOnline
                            ? ThemeConstants.successColor
                            : ThemeConstants.errorColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildInfoCard(
                  'Temp',
                  '${(_latestSensorData?.temperature ?? widget.device.sensorData.temperature).toStringAsFixed(1)}°C',
                  Icons.thermostat,
                  ThemeConstants.infoColor,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildInfoCard(
                  'Humidity',
                  '${(_latestSensorData?.humidity ?? widget.device.sensorData.humidity).toStringAsFixed(1)}%',
                  Icons.water_drop,
                  ThemeConstants.primaryColor,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildInfoCard(
                  'Weather',
                  (_latestSensorData?.rainDetected ?? widget.device.sensorData.rainDetected) ? 'Rain' : 'Clear',
                  (_latestSensorData?.rainDetected ?? widget.device.sensorData.rainDetected) ? Icons.umbrella : Icons.wb_sunny,
                  (_latestSensorData?.rainDetected ?? widget.device.sensorData.rainDetected)
                      ? ThemeConstants.warningColor 
                      : ThemeConstants.successColor,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

Widget _buildTabBar() {
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
    ),
    child: TabBar(
      controller: _tabController,
      tabs: const [
        Tab(text: 'Overview', icon: Icon(Icons.dashboard)),
        Tab(text: 'Controls', icon: Icon(Icons.settings_remote)),
        Tab(text: 'Config', icon: Icon(Icons.tune)),
        Tab(text: 'Alerts', icon: Icon(Icons.notifications)),
      ],
      labelColor: ThemeConstants.primaryColor,
      unselectedLabelColor: Colors.grey[600],
      indicatorSize: TabBarIndicatorSize.tab, // Makes indicator match tab size
      indicator: BoxDecoration(
        color: ThemeConstants.primaryColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
    ),
  );
}

  Widget _buildTabBarView() {
    return SizedBox(
      height: 600,
      child: TabBarView(
        controller: _tabController,
        children: [
          _buildOverviewTab(),
          _buildControlsTab(),
          _buildConfigTab(),
          _buildAlertsTab(),
        ],
      ),
    );
  }

  Widget _buildOverviewTab() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Sensor Data Chart',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 300,
            child: SensorChart(deviceId: widget.device.id),
          ),
        ],
      ),
    );
  }

  Widget _buildControlsTab() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: DeviceControls(
        device: widget.device,
        //onCommandSent: _handleCommandSent,
      ),
    );
  }

  Widget _buildConfigTab() {
    return DeviceConfigTab(device: widget.device);
  }

  Widget _buildAlertsTab() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: AlertList(),
    );
  }

  Widget _buildFloatingActionButton() {
    return FloatingActionButton.extended(
      onPressed: _refreshDeviceData,
      backgroundColor: ThemeConstants.primaryColor,
      icon: _isLoading 
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            )
          : const Icon(Icons.refresh, color: Colors.white),
      label: const Text(
        'Refresh',
        style: TextStyle(color: Colors.white),
      ),
    );
  }

  void _handleCommandSent(String command) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Command "$command" sent to ${widget.device.name}'),
        backgroundColor: ThemeConstants.successColor,
      ),
    );
  }

  Future<void> _refreshDeviceData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Trigger a refresh in the device provider
      final deviceProvider = Provider.of<DeviceProvider>(context, listen: false);
      await Future.delayed(const Duration(seconds: 1)); // Simulate refresh
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Device data refreshed'),
            backgroundColor: ThemeConstants.successColor,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ErrorHandler.showErrorSnackBar(context, 'Failed to refresh device data');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  IconData _getDeviceIcon() {
    switch (widget.device.status) {
      case DeviceStatus.extended:
        return Icons.unfold_more;
      case DeviceStatus.retracted:
        return Icons.unfold_less;
      case DeviceStatus.moving:
        return Icons.sync;
      case DeviceStatus.error:
        return Icons.error;
      case DeviceStatus.offline:
        return Icons.wifi_off;
    }
  }

  Color _getStatusColor() {
    switch (widget.device.status) {
      case DeviceStatus.extended:
        return ThemeConstants.successColor;
      case DeviceStatus.retracted:
        return ThemeConstants.infoColor;
      case DeviceStatus.moving:
        return ThemeConstants.warningColor;
      case DeviceStatus.error:
        return ThemeConstants.errorColor;
      case DeviceStatus.offline:
        return Colors.grey;
    }
  }





  void _showEditDeviceNameDialog(BuildContext context) {
    final TextEditingController nameController = TextEditingController(text: widget.device.name);
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit Device Name'),
          content: TextField(
            controller: nameController,
            decoration: const InputDecoration(
              labelText: 'Device Name',
              border: OutlineInputBorder(),
            ),
            maxLength: 50,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                final newName = nameController.text.trim();
                if (newName.isNotEmpty && newName != widget.device.name) {
                  try {
                    await FirebaseService.updateDeviceInfo(widget.device.id, {
                      'info/deviceName': newName,
                    });
                    
                    if (context.mounted) {
                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Device name updated successfully'),
                          backgroundColor: ThemeConstants.successColor,
                        ),
                      );
                    }
                  } catch (e) {
                    if (context.mounted) {
                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Failed to update device name: $e'),
                          backgroundColor: ThemeConstants.errorColor,
                        ),
                      );
                    }
                  }
                } else {
                  Navigator.of(context).pop();
                }
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }


} 