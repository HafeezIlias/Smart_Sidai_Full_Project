import 'package:flutter/material.dart';

class ConnectivityProvider extends ChangeNotifier {
  bool _isConnected = true;

  bool get isConnected => _isConnected;

  void setConnected(bool connected) {
    _isConnected = connected;
    notifyListeners();
  }
} 