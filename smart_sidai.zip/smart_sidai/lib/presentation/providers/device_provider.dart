import 'package:flutter/material.dart';
import 'dart:async';
import '../../data/models/device_model.dart';
import '../../data/models/device_status.dart';
import '../../services/firebase/firebase_routes.dart';

class DeviceProvider extends ChangeNotifier {
  List<DeviceModel> _devices = [];
  bool _isLoading = true;
  String? _error;
  StreamSubscription<List<DeviceModel>>? _devicesSubscription;

  List<DeviceModel> get devices => _devices;
  bool get isLoading => _isLoading;
  String? get error => _error;

  DeviceProvider() {
    _loadDevices();
  }

  @override
  void dispose() {
    _devicesSubscription?.cancel();
    super.dispose();
  }

  void _loadDevices() {
    _isLoading = true;
    _error = null;
    notifyListeners();

    // Listen to real-time updates from Firebase
    _devicesSubscription?.cancel();
    _devicesSubscription = FirebaseService.getDevicesStream().listen(
      (devices) {
        _devices = devices;
        _isLoading = false;
        _error = null;
        notifyListeners();
      },
      onError: (error) {
        _error = error.toString();
        _isLoading = false;
        notifyListeners();
      },
    );
  }



  Future<void> sendCommand(String deviceId, String command) async {
    try {
      await FirebaseService.sendCommand(deviceId, command);
      
      // Update requested state in config instead of status
      String requestedState;
        
        switch (command.toLowerCase()) {
          case 'extend':
          requestedState = 'EXTENDED';
            break;
          case 'retract':
          requestedState = 'RETRACTED';
            break;
          case 'start':
          requestedState = 'MOVING';
            break;
          default:
          requestedState = 'RETRACTED';
        }
        
      // Update requestedState in config
      await FirebaseService.updateDeviceConfig(deviceId, {
        'requestedState': requestedState,
      });
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }

  DeviceModel? getDeviceById(String id) {
    try {
      return _devices.firstWhere((device) => device.id == id);
    } catch (e) {
      return null;
    }
  }

  List<DeviceModel> get onlineDevices => _devices.where((device) => device.isOnline).toList();
  List<DeviceModel> get offlineDevices => _devices.where((device) => !device.isOnline).toList();

  void clearError() {
    _error = null;
    notifyListeners();
  }

  Future<void> refreshDevices() async {
    try {
      _isLoading = true;
      notifyListeners();
      
      // Force refresh from Firebase
      final devices = await FirebaseService.getAllDevices();
      _devices = devices;
      _error = null;
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> updateDeviceStatus(String deviceId, DeviceStatus newStatus) async {
    try {
      await FirebaseService.updateDeviceStatus(deviceId, newStatus);
      // The real-time listener will handle the UI update
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    }
  }
} 