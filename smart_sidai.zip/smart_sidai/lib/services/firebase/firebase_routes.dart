import 'package:firebase_database/firebase_database.dart';
import '../../data/models/device_model.dart';
import '../../data/models/device_status.dart';
import '../../data/models/alert_model.dart';
import '../../data/models/sensor_data.dart';

class FirebaseService {
  static final FirebaseDatabase _database = FirebaseDatabase.instance;
  
  // Database references
  static DatabaseReference get _devicesRef => _database.ref('devices');
  static DatabaseReference get _alertsRef => _database.ref('alerts');
  static DatabaseReference get _sensorDataRef => _database.ref('sensors');
  static DatabaseReference get _commandsRef => _database.ref('commands');

  // Get all devices
  static Future<List<DeviceModel>> getAllDevices() async {
    try {
      final snapshot = await _devicesRef.get();
      if (snapshot.exists) {
        final devicesMap = snapshot.value as Map<dynamic, dynamic>;
        return devicesMap.entries
            .map((entry) => DeviceModel.fromMap(entry.value, entry.key))
            .toList();
      }
      return [];
    } catch (e) {
      throw Exception('Failed to fetch devices: $e');
    }
  }

  // Get device by ID
  static Future<DeviceModel?> getDeviceById(String deviceId) async {
    try {
      final snapshot = await _devicesRef.child(deviceId).get();
      if (snapshot.exists) {
        return DeviceModel.fromMap(snapshot.value as Map<dynamic, dynamic>, deviceId);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to fetch device: $e');
    }
  }

  // Listen to devices real-time
  static Stream<List<DeviceModel>> getDevicesStream() {
    return _devicesRef.onValue.map((event) {
      if (event.snapshot.exists) {
        final devicesMap = event.snapshot.value as Map<dynamic, dynamic>;
        return devicesMap.entries
            .map((entry) => DeviceModel.fromMap(entry.value, entry.key))
            .toList();
      }
      return <DeviceModel>[];
    });
  }

  // Listen to specific device real-time
  static Stream<DeviceModel?> getDeviceStream(String deviceId) {
    return _devicesRef.child(deviceId).onValue.map((event) {
      if (event.snapshot.exists) {
        return DeviceModel.fromMap(event.snapshot.value as Map<dynamic, dynamic>, deviceId);
      }
      return null;
    });
  }

  // Update device status
  static Future<void> updateDeviceStatus(String deviceId, DeviceStatus status) async {
    try {
      await _devicesRef.child(deviceId).child('status').update({
        'state': status.displayName,
        'timestamp': DateTime.now().millisecondsSinceEpoch.toString(),
      });
    } catch (e) {
      throw Exception('Failed to update device status: $e');
    }
  }

  // Send command to device
  static Future<void> sendCommand(String deviceId, String command) async {
    try {
      final commandId = _commandsRef.child(deviceId).push().key;
      await _commandsRef.child(deviceId).child(commandId!).set({
        'command': command,
        'timestamp': DateTime.now().toIso8601String(),
        'status': 'PENDING',
        'deviceId': deviceId,
      });
    } catch (e) {
      throw Exception('Failed to send command: $e');
    }
  }

  // Get sensor data for a device
  static Future<List<SensorData>> getSensorData(String deviceId, {int limit = 50}) async {
    try {
      final snapshot = await _database
          .ref('devices')
          .child(deviceId)
          .child('sensors')
          .child('logs')
          .orderByChild('timestamp')
          .limitToLast(limit)
          .get();
      
      if (snapshot.exists) {
        final dataMap = snapshot.value as Map<dynamic, dynamic>;
        final sensorDataList = dataMap.values
            .map((data) => SensorData.fromMap(data))
            .toList();
        
        // Sort by timestamp numerically (newest first) to ensure proper ordering
        sensorDataList.sort((a, b) => b.timestamp.compareTo(a.timestamp));
        
        return sensorDataList;
      }
      return [];
    } catch (e) {
      throw Exception('Failed to fetch sensor data: $e');
    }
  }

  // Listen to sensor data real-time
  static Stream<List<SensorData>> getSensorDataStream(String deviceId, {int limit = 50}) {
    return _database
        .ref('devices')
        .child(deviceId)
        .child('sensors')
        .child('logs')
        .orderByChild('timestamp')
        .limitToLast(limit)
        .onValue
        .map((event) {
      if (event.snapshot.exists) {
        final dataMap = event.snapshot.value as Map<dynamic, dynamic>;
        final sensorDataList = dataMap.values
            .map((data) => SensorData.fromMap(data))
            .toList();
        
        // Sort by timestamp numerically (newest first) to ensure proper ordering
        sensorDataList.sort((a, b) => b.timestamp.compareTo(a.timestamp));
        
        return sensorDataList;
      }
      return <SensorData>[];
    });
  }

  // Get all alerts
  static Future<List<AlertModel>> getAllAlerts({bool onlyUnresolved = false}) async {
    try {
      Query query = _alertsRef.orderByChild('timestamp');
      if (onlyUnresolved) {
        query = query.orderByChild('resolved').equalTo(false);
      }
      
      final snapshot = await query.get();
      if (snapshot.exists) {
        final alertsMap = snapshot.value as Map<dynamic, dynamic>;
        return alertsMap.entries
            .map((entry) => AlertModel.fromMap(entry.value, entry.key))
            .toList()
            ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
      }
      return [];
    } catch (e) {
      throw Exception('Failed to fetch alerts: $e');
    }
  }

  // Listen to alerts real-time
  static Stream<List<AlertModel>> getAlertsStream({bool onlyUnresolved = false}) {
    Query query = _alertsRef.orderByChild('timestamp');
    return query.onValue.map((event) {
      if (event.snapshot.exists) {
        final alertsMap = event.snapshot.value as Map<dynamic, dynamic>;
        List<AlertModel> alerts = alertsMap.entries
            .map((entry) => AlertModel.fromMap(entry.value, entry.key))
            .toList();
        
        if (onlyUnresolved) {
          alerts = alerts.where((alert) => !alert.resolved).toList();
        }
        
        return alerts..sort((a, b) => b.timestamp.compareTo(a.timestamp));
      }
      return <AlertModel>[];
    });
  }

  // Create alert
  static Future<void> createAlert({
    required String deviceId,
    required String deviceName,
    required String location,
    required AlertType type,
    required String message,
  }) async {
    try {
      final alertId = _alertsRef.push().key;
      await _alertsRef.child(alertId!).set({
        'deviceID': deviceId,
        'deviceName': deviceName,
        'location': location,
        'type': type.name.toUpperCase(),
        'message': message,
        'timestamp': DateTime.now().toIso8601String(),
        'resolved': false,
      });
    } catch (e) {
      throw Exception('Failed to create alert: $e');
    }
  }

  // Resolve alert
  static Future<void> resolveAlert(String alertId) async {
    try {
      await _alertsRef.child(alertId).update({
        'resolved': true,
        'resolvedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('Failed to resolve alert: $e');
    }
  }

  // Add new device (for registration)
  static Future<void> addDevice(DeviceModel device) async {
    try {
      await _devicesRef.child(device.id).set(device.toMap());
    } catch (e) {
      throw Exception('Failed to add device: $e');
    }
  }

  // Remove device
  static Future<void> removeDevice(String deviceId) async {
    try {
      await _devicesRef.child(deviceId).remove();
      await _commandsRef.child(deviceId).remove();
    } catch (e) {
      throw Exception('Failed to remove device: $e');
    }
  }

  // Update device information
  static Future<void> updateDeviceInfo(String deviceId, Map<String, dynamic> updates) async {
    try {
      await _devicesRef.child(deviceId).update(updates);
    } catch (e) {
      throw Exception('Failed to update device info: $e');
    }
  }

  // Update device configuration
  static Future<void> updateDeviceConfig(String deviceId, Map<String, dynamic> configUpdates) async {
    try {
      await _devicesRef.child(deviceId).child('config').update(configUpdates);
    } catch (e) {
      throw Exception('Failed to update device config: $e');
    }
  }

  // Get device statistics
  static Future<Map<String, dynamic>> getDeviceStats() async {
    try {
      final devicesSnapshot = await _devicesRef.get();
      if (!devicesSnapshot.exists) {
        return {
          'totalDevices': 0,
          'onlineDevices': 0,
          'offlineDevices': 0,
          'errorDevices': 0,
        };
      }

      final devicesMap = devicesSnapshot.value as Map<dynamic, dynamic>;
      final devices = devicesMap.values.toList();
      
      int totalDevices = devices.length;
      int onlineDevices = 0;
      int offlineDevices = 0;
      int errorDevices = 0;

      for (var device in devices) {
        final status = device['status'];
        final isOnline = status?['systemHealth'] == 'OK' && status?['wifiConnected'] == true;
        final currentState = status?['currentState'] ?? 'OFFLINE';
        
        if (currentState == 'ERROR') {
          errorDevices++;
        } else if (isOnline) {
          onlineDevices++;
        } else {
          offlineDevices++;
        }
      }

      return {
        'totalDevices': totalDevices,
        'onlineDevices': onlineDevices,
        'offlineDevices': offlineDevices,
        'errorDevices': errorDevices,
      };
    } catch (e) {
      throw Exception('Failed to get device stats: $e');
    }
  }
}