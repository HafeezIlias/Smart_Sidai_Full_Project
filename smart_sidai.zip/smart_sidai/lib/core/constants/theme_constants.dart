import 'package:flutter/material.dart';

class ThemeConstants {
  // Primary Colors
  static const Color primaryColor = Color(0xFF2E7D32);        // Forest Green
  static const Color primaryLight = Color(0xFF66BB6A);        // Light Green
  static const Color primaryDark = Color(0xFF1B5E20);         // Dark Green

  // Accent Colors
  static const Color accentColor = Color(0xFF4CAF50);         // Material Green
  static const Color secondaryColor = Color(0xFF81C784);      // Light Green

  // Status Colors
  static const Color successColor = Color(0xFF4CAF50);        // Success Green
  static const Color warningColor = Color(0xFFFF9800);        // Warning Orange
  static const Color errorColor = Color(0xFFF44336);          // Error Red
  static const Color infoColor = Color(0xFF2196F3);           // Info Blue

  // Background Colors
  static const Color lightBackground = Color(0xFFF8F9FA);
  static const Color darkBackground = Color(0xFF121212);
  static const Color cardBackgroundLight = Color(0xFFFFFFFF);
  static const Color cardBackgroundDark = Color(0xFF1E1E1E);

  // Text Colors
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
  static const Color textHint = Color(0xFFBDBDBD);
  static const Color textOnPrimary = Color(0xFFFFFFFF);

  // Border Colors
  static const Color borderLight = Color(0xFFE0E0E0);
  static const Color borderDark = Color(0xFF424242);

  // Gradient Colors
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryColor, primaryLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient successGradient = LinearGradient(
    colors: [Color(0xFF4CAF50), Color(0xFF81C784)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient warningGradient = LinearGradient(
    colors: [Color(0xFFFF9800), Color(0xFFFFB74D)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient errorGradient = LinearGradient(
    colors: [Color(0xFFF44336), Color(0xFFE57373)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Shadow Colors
  static final Color shadowLight = Colors.black.withOpacity(0.08);
  static final Color shadowDark = Colors.black.withOpacity(0.25);

  // Device Status Colors
  static const Color deviceOnlineColor = Color(0xFF4CAF50);
  static const Color deviceOfflineColor = Color(0xFF757575);
  static const Color deviceErrorColor = Color(0xFFF44336);
  static const Color deviceWarningColor = Color(0xFFFF9800);

  // Chart Colors
  static const List<Color> chartColors = [
    Color(0xFF2E7D32),  // Primary Green
    Color(0xFF1976D2),  // Blue
    Color(0xFFFF9800),  // Orange
    Color(0xFF9C27B0),  // Purple
    Color(0xFFE91E63),  // Pink
    Color(0xFF00BCD4),  // Cyan
    Color(0xFF795548),  // Brown
    Color(0xFF607D8B),  // Blue Grey
  ];

  // Animation Colors
  static const Color pulseColorLight = Color(0xFF4CAF50);
  static const Color pulseColorDark = Color(0xFF81C784);

  // Size Constants
  static const double iconSizeSmall = 16.0;
  static const double iconSizeMedium = 24.0;
  static const double iconSizeLarge = 32.0;
  static const double iconSizeXLarge = 48.0;

  // Elevation Constants
  static const double elevationSmall = 2.0;
  static const double elevationMedium = 4.0;
  static const double elevationLarge = 8.0;
  static const double elevationXLarge = 12.0;

  // Border Radius Constants
  static const double radiusSmall = 8.0;
  static const double radiusMedium = 12.0;
  static const double radiusLarge = 16.0;
  static const double radiusXLarge = 24.0;

  // Spacing Constants
  static const double spacingXSmall = 4.0;
  static const double spacingSmall = 8.0;
  static const double spacingMedium = 16.0;
  static const double spacingLarge = 24.0;
  static const double spacingXLarge = 32.0;

  // Opacity Constants
  static const double opacityLow = 0.3;
  static const double opacityMedium = 0.6;
  static const double opacityHigh = 0.8;
  static const double opacityDisabled = 0.4;

  // Device State Color Map
  static const Map<String, Color> deviceStateColors = {
    'EXTENDED': successColor,
    'RETRACTED': infoColor,
    'MOVING': warningColor,
    'ERROR': errorColor,
    'OFFLINE': Color(0xFF757575),
  };

  // Alert Type Color Map
  static const Map<String, Color> alertTypeColors = {
    'INFO': infoColor,
    'WARNING': warningColor,
    'ERROR': errorColor,
    'EMERGENCY': Color(0xFFD32F2F),
  };
} 