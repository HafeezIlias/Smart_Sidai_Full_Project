class AppConstants {
  // App Information
  static const String appName = 'Smart Sidai';
  static const String appVersion = '1.0.0';
  static const String appDescription = 'Smart Clothes Hanger Management System';

  // Device Commands
  static const String commandExtend = 'EXTEND';
  static const String commandRetract = 'RETRACT';
  static const String commandAuto = 'AUTO';
  static const String commandStop = 'STOP';

  // Sensor Thresholds
  static const double temperatureMax = 35.0;
  static const double temperatureMin = 5.0;
  static const double humidityMax = 85.0;
  static const double humidityMin = 30.0;

  // App Settings
  static const int splashDuration = 3000; // milliseconds
  static const int refreshInterval = 5000; // milliseconds
  static const int timeoutDuration = 10000; // milliseconds

  // Storage Keys
  static const String keyThemeMode = 'theme_mode';
  static const String keyNotificationsEnabled = 'notifications_enabled';
  static const String keyAutoRefresh = 'auto_refresh';
  static const String keyUserName = 'user_name';
  static const String keyFirstLaunch = 'first_launch';

  // Notification Settings
  static const String notificationChannelId = 'smart_sidai_channel';
  static const String notificationChannelName = 'Smart Sidai Notifications';
  static const String notificationChannelDescription = 'Notifications for Smart Sidai device alerts and updates';

  // Database Paths
  static const String smartHangerPath = 'smartHanger';
  static const String devicesPath = 'smartHanger/devices';
  static const String sensorDataPath = 'sensorData';
  static const String statusPath = 'status';
  static const String commandsPath = 'commands';
  static const String alertsPath = 'alerts';
  static const String configPath = 'config';

  // Refresh Intervals (in seconds)
  static const int sensorRefreshInterval = 2;
  static const int statusRefreshInterval = 5;
  static const int alertsRefreshInterval = 10;

  // Animation Durations (in milliseconds)
  static const int quickAnimationDuration = 150;
  static const int mediumAnimationDuration = 300;
  static const int longAnimationDuration = 500;

  // UI Constants
  static const double defaultPadding = 16.0;
  static const double smallPadding = 8.0;
  static const double largePadding = 24.0;
  static const double defaultBorderRadius = 12.0;
  static const double cardBorderRadius = 16.0;
  static const double cardElevation = 4.0;

  // Device States
  static const String deviceStateExtended = 'EXTENDED';
  static const String deviceStateRetracted = 'RETRACTED';
  static const String deviceStateMoving = 'MOVING';
  static const String deviceStateError = 'ERROR';

  // Device Constants
  static const int maxDevices = 10;
  static const Duration connectionTimeout = Duration(seconds: 30);
  
  // Alert Types
  static const String alertTypeInfo = 'INFO';
  static const String alertTypeWarning = 'WARNING';
  static const String alertTypeError = 'ERROR';
  static const String alertTypeEmergency = 'EMERGENCY';

  // Network
  static const int networkTimeoutDuration = 30; // seconds
  static const int maxRetryAttempts = 3;

  // Chart Configuration
  static const int maxDataPoints = 50;
  static const int chartUpdateInterval = 5; // seconds
} 