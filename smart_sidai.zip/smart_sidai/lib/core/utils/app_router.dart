import 'package:flutter/material.dart';

// Screens
import '../../presentation/screens/splash/splash_screen.dart';
import '../../presentation/screens/main_screen.dart';
import '../../presentation/screens/dashboard/dashboard_screen.dart';
import '../../presentation/screens/device_list/device_list_screen.dart';
import '../../presentation/screens/device_details/device_details_screen.dart';
import '../../presentation/screens/settings/settings_screen.dart';
import '../../presentation/screens/alerts/alerts_screen.dart';
import '../../presentation/screens/profile/profile_screen.dart';

// Models
import '../../data/models/device_model.dart';

class AppRouter {
  // Route Names
  static const String splash = '/';
  static const String main = '/main';
  static const String dashboard = '/dashboard';
  static const String deviceList = '/device-list';
  static const String deviceDetails = '/device-details';
  static const String settings = '/settings';
  static const String alerts = '/alerts';
  static const String profile = '/profile';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRouter.splash:
        return _buildRoute(const SplashScreen(), settings);

      case AppRouter.main:
        return _buildRoute(const MainScreen(), settings);

      case AppRouter.dashboard:
        return _buildRoute(const DashboardScreen(), settings);

      case AppRouter.deviceList:
        return _buildRoute(const DeviceListScreen(), settings);

      case AppRouter.deviceDetails:
        final device = settings.arguments as DeviceModel?;
        if (device != null) {
          return _buildRoute(DeviceDetailsScreen(device: device), settings);
        }
        return _buildErrorRoute('Device not found');

      case AppRouter.settings:
        return _buildRoute(const SettingsScreen(), settings);

      case AppRouter.alerts:
        return _buildRoute(const AlertsScreen(), settings);

      case AppRouter.profile:
        return _buildRoute(const ProfileScreen(), settings);

      default:
        return _buildErrorRoute('Route not found: ${settings.name}');
    }
  }

  static Route<dynamic> _buildRoute(Widget screen, RouteSettings settings) {
    return PageRouteBuilder(
      settings: settings,
      pageBuilder: (context, animation, secondaryAnimation) => screen,
      transitionDuration: const Duration(milliseconds: 300),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.easeInOut;

        var tween = Tween(begin: begin, end: end).chain(
          CurveTween(curve: curve),
        );

        return SlideTransition(
          position: animation.drive(tween),
          child: FadeTransition(
            opacity: animation,
            child: child,
          ),
        );
      },
    );
  }

  static Route<dynamic> _buildErrorRoute(String message) {
    return MaterialPageRoute(
      builder: (context) => Scaffold(
        appBar: AppBar(
          title: const Text('Error'),
          centerTitle: true,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.error_outline,
                size: 64,
                color: Colors.red,
              ),
              const SizedBox(height: 16),
              Text(
                message,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pushReplacementNamed(AppRouter.dashboard),
                child: const Text('Go to Dashboard'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Navigation Helper Methods
  static Future<void> navigateToSplash(BuildContext context) {
    return Navigator.of(context).pushReplacementNamed(splash);
  }

  static Future<void> navigateToMain(BuildContext context) {
    return Navigator.of(context).pushReplacementNamed(main);
  }

  static Future<void> navigateToDashboard(BuildContext context) {
    return Navigator.of(context).pushReplacementNamed(dashboard);
  }

  static Future<void> navigateToDeviceList(BuildContext context) {
    return Navigator.of(context).pushNamed(deviceList);
  }

  static Future<void> navigateToDeviceDetails(
    BuildContext context,
    DeviceModel device,
  ) {
    return Navigator.of(context).pushNamed(
      deviceDetails,
      arguments: device,
    );
  }

  static Future<void> navigateToSettings(BuildContext context) {
    return Navigator.of(context).pushNamed(settings);
  }

  static Future<void> navigateToAlerts(BuildContext context) {
    return Navigator.of(context).pushNamed(alerts);
  }

  static Future<void> navigateToProfile(BuildContext context) {
    return Navigator.of(context).pushNamed(profile);
  }

  static void pop(BuildContext context) {
    Navigator.of(context).pop();
  }

  static void popUntil(BuildContext context, String routeName) {
    Navigator.of(context).popUntil(ModalRoute.withName(routeName));
  }
} 