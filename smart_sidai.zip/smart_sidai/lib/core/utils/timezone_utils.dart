class TimezoneUtils {
  // UTC+8 offset in milliseconds (8 hours * 60 minutes * 60 seconds * 1000 milliseconds)
  static const int utcPlus8OffsetMs = 8 * 60 * 60 * 1000;
  
  /// Converts UTC timestamp (in milliseconds) to local time (UTC+8)
  static DateTime utcToLocal(int utcTimestampMs) {
    final localTimestamp = utcTimestampMs + utcPlus8OffsetMs;
    return DateTime.fromMillisecondsSinceEpoch(localTimestamp);
  }
  
  /// Converts local time (UTC+8) to UTC timestamp (in milliseconds)
  static int localToUtc(DateTime localDateTime) {
    final utcTimestamp = localDateTime.millisecondsSinceEpoch - utcPlus8OffsetMs;
    return utcTimestamp;
  }
  
  /// Safely parses timestamp string/int and converts to local DateTime
  static DateTime parseTimestamp(dynamic timestamp) {
    final utcTimestamp = int.tryParse(timestamp?.toString() ?? '0') ?? 0;
    
    // If timestamp is 0 or invalid, return current time
    if (utcTimestamp == 0) {
      return DateTime.now();
    }
    
    return utcToLocal(utcTimestamp);
  }
  
  /// Formats a relative time string (e.g., "2m ago", "1h ago")
  static String formatRelativeTime(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);
    
    if (difference.inSeconds < 60) {
      return '${difference.inSeconds}s ago';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }
} 