class SensorData {
  final double temperature;
  final double humidity;
  final bool rainDetected;
  final bool userPresent;
  final bool motorRunning;
  final String weatherCondition;
  final double distance;
  final DateTime timestamp;

  SensorData({
    required this.temperature,
    required this.humidity,
    required this.rainDetected,
    required this.userPresent,
    required this.motorRunning,
    required this.weatherCondition,
    this.distance = 0.0,
    required this.timestamp,
  });

  factory SensorData.fromMap(Map<dynamic, dynamic> map) {
    return SensorData(
      temperature: (map['temperature'] ?? 0.0).toDouble(),
      humidity: (map['humidity'] ?? 0.0).toDouble(),
      rainDetected: map['rainDetected'] ?? false,
      userPresent: map['userPresent'] ?? false,
      motorRunning: false, // This is in status, not sensor data
      weatherCondition: map['rainDetected'] == true ? 'Rainy' : 'Clear',
      distance: (map['distance'] ?? 0.0).toDouble(),
      timestamp: _parseTimestamp(map['timestamp']),
    );
  }

  // Helper method to parse timestamp and convert to local time (UTC+8)
  static DateTime _parseTimestamp(dynamic timestamp) {
    final timestampValue = int.tryParse(timestamp?.toString() ?? '0') ?? 0;
    if (timestampValue == 0) {
      return DateTime.now();
    }
    
    // Current Unix timestamp (in seconds) is around 1700000000+ (year 2023+)
    // Current Unix timestamp (in milliseconds) is around 1700000000000+ (year 2023+)
    
    int timestampMs;
    
    // Check different timestamp formats
    if (timestampValue > 1000000000000000) {
      // This might be microseconds (16+ digits), convert to milliseconds
      timestampMs = (timestampValue / 1000).round();
    } else if (timestampValue > 1000000000000) {
      // This looks like milliseconds (13+ digits)
      timestampMs = timestampValue;
    } else if (timestampValue > 1000000000) {
      // This looks like seconds (10+ digits), convert to milliseconds
      timestampMs = timestampValue * 1000;
    } else {
      // Handle very small timestamps (like the earlier examples: 18661, 18657)
      // These might be in a different format, so we add the UTC+8 offset directly
      final localTimestamp = timestampValue + (8 * 60 * 60 * 1000);
      return DateTime.fromMillisecondsSinceEpoch(localTimestamp);
    }
    
    // Now we have timestamp in milliseconds
    // Check if it's in a reasonable range (2020-2035)
    final testDate = DateTime.fromMillisecondsSinceEpoch(timestampMs, isUtc: true);
    if (testDate.year < 2020 || testDate.year > 2035) {
      // If the date is still unreasonable, try treating original as seconds
      if (timestampValue > 1600000000 && timestampValue < 2000000000) {
        // This looks like a reasonable Unix timestamp in seconds
        final secondsDate = DateTime.fromMillisecondsSinceEpoch(timestampValue * 1000, isUtc: true);
        return secondsDate.add(const Duration(hours: 8));
      }
      // Otherwise return current time
      return DateTime.now();
    }
    
    // Convert UTC to local time (UTC+8)
    return testDate.add(const Duration(hours: 8));
  }

  Map<String, dynamic> toMap() {
    return {
      'temperature': temperature,
      'humidity': humidity,
      'rainDetected': rainDetected,
      'userPresent': userPresent,
      'motorRunning': motorRunning,
      'weatherCondition': weatherCondition,
      'distance': distance,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  SensorData copyWith({
    double? temperature,
    double? humidity,
    bool? rainDetected,
    bool? userPresent,
    bool? motorRunning,
    String? weatherCondition,
    double? distance,
    DateTime? timestamp,
  }) {
    return SensorData(
      temperature: temperature ?? this.temperature,
      humidity: humidity ?? this.humidity,
      rainDetected: rainDetected ?? this.rainDetected,
      userPresent: userPresent ?? this.userPresent,
      motorRunning: motorRunning ?? this.motorRunning,
      weatherCondition: weatherCondition ?? this.weatherCondition,
      distance: distance ?? this.distance,
      timestamp: timestamp ?? this.timestamp,
    );
  }
} 