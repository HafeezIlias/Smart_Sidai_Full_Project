class AlertModel {
  final String id;
  final String deviceId;
  final String deviceName;
  final String location;
  final AlertType type;
  final String message;
  final DateTime timestamp;
  final bool resolved;

  AlertModel({
    required this.id,
    required this.deviceId,
    required this.deviceName,
    required this.location,
    required this.type,
    required this.message,
    required this.timestamp,
    required this.resolved,
  });

  factory AlertModel.fromMap(Map<dynamic, dynamic> map, String alertId) {
    return AlertModel(
      id: alertId,
      deviceId: map['deviceID'] ?? '',
      deviceName: map['deviceName'] ?? 'Unknown Device',
      location: map['location'] ?? 'Unknown Location',
      type: AlertType.fromString(map['type'] ?? 'INFO'),
      message: map['message'] ?? '',
      timestamp: DateTime.tryParse(map['timestamp']?.toString() ?? '') ?? DateTime.now(),
      resolved: map['resolved'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'deviceID': deviceId,
      'deviceName': deviceName,
      'location': location,
      'type': type.toString(),
      'message': message,
      'timestamp': timestamp.toIso8601String(),
      'resolved': resolved,
    };
  }
}

enum AlertType {
  info,
  warning,
  error,
  emergency;

  static AlertType fromString(String type) {
    switch (type.toUpperCase()) {
      case 'INFO':
        return AlertType.info;
      case 'WARNING':
        return AlertType.warning;
      case 'ERROR':
        return AlertType.error;
      case 'EMERGENCY':
        return AlertType.emergency;
      default:
        return AlertType.info;
    }
  }

  @override
  String toString() {
    return name.toUpperCase();
  }

  String get displayName {
    switch (this) {
      case AlertType.info:
        return 'Info';
      case AlertType.warning:
        return 'Warning';
      case AlertType.error:
        return 'Error';
      case AlertType.emergency:
        return 'Emergency';
    }
  }
} 