import 'device_status.dart';
import 'sensor_data.dart';
import 'device_info.dart';

class DeviceConfig {
  final double tempMinThreshold;
  final double tempMaxThreshold;
  final double humidityMinThreshold;
  final double humidityMaxThreshold;
  final int motorTimeout;
  final int sensorReadInterval;
  final bool useCustomThresholds;
  final bool autoMode;
  final int distanceExtended;
  final int distanceRetracted;
  final bool enablePirControl;
  final bool retractOnUserPresent;
  final int pirRetractDelay;
  final String requestedState;

  const DeviceConfig({
    this.tempMinThreshold = 0.0,
    this.tempMaxThreshold = 35.0,
    this.humidityMinThreshold = 30.0,
    this.humidityMaxThreshold = 80.0,
    this.motorTimeout = 30000,
    this.sensorReadInterval = 2000,
    this.useCustomThresholds = false,
    this.autoMode = true,
    this.distanceExtended = 50,
    this.distanceRetracted = 20,
    this.enablePirControl = false,
    this.retractOnUserPresent = false,
    this.pirRetractDelay = 0,
    this.requestedState = 'none',
  });

  factory DeviceConfig.fromMap(Map<dynamic, dynamic> map) {
    return DeviceConfig(
      tempMinThreshold: (map['tempMinThreshold'] ?? 0.0).toDouble(),
      tempMaxThreshold: (map['tempMaxThreshold'] ?? 35.0).toDouble(),
      humidityMinThreshold: (map['humidityMinThreshold'] ?? 30.0).toDouble(),
      humidityMaxThreshold: (map['humidityMaxThreshold'] ?? 80.0).toDouble(),
      motorTimeout: (map['motorTimeout'] ?? 30000).toInt(),
      sensorReadInterval: (map['sensorReadInterval'] ?? 2000).toInt(),
      useCustomThresholds: map['useCustomThresholds'] ?? false,
      autoMode: map['autoMode'] ?? true,
      distanceExtended: (map['distanceExtended'] ?? 50).toInt(),
      distanceRetracted: (map['distanceRetracted'] ?? 20).toInt(),
      enablePirControl: map['enablePirControl'] ?? false,
      retractOnUserPresent: map['retractOnUserPresent'] ?? false,
      pirRetractDelay: (map['pirRetractDelay'] ?? 0).toInt(),
      requestedState: map['requestedState'] ?? 'none',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'tempMinThreshold': tempMinThreshold,
      'tempMaxThreshold': tempMaxThreshold,
      'humidityMinThreshold': humidityMinThreshold,
      'humidityMaxThreshold': humidityMaxThreshold,
      'motorTimeout': motorTimeout,
      'sensorReadInterval': sensorReadInterval,
      'useCustomThresholds': useCustomThresholds,
      'autoMode': autoMode,
      'distanceExtended': distanceExtended,
      'distanceRetracted': distanceRetracted,
      'enablePirControl': enablePirControl,
      'retractOnUserPresent': retractOnUserPresent,
      'pirRetractDelay': pirRetractDelay,
      'requestedState': requestedState,
    };
  }

  DeviceStatus get requestedDeviceStatus {
    switch (requestedState.toUpperCase()) {
      case 'EXTENDED':
        return DeviceStatus.extended;
      case 'RETRACTED':
        return DeviceStatus.retracted;
      case 'MOVING':
        return DeviceStatus.moving;
      case 'ERROR':
        return DeviceStatus.error;
      case 'NONE':
      case '':
        return DeviceStatus.offline; // Treat "none" as offline/no requested state
      default:
        return DeviceStatus.retracted;
    }
  }

  DeviceConfig copyWith({
    double? tempMinThreshold,
    double? tempMaxThreshold,
    double? humidityMinThreshold,
    double? humidityMaxThreshold,
    int? motorTimeout,
    int? sensorReadInterval,
    bool? useCustomThresholds,
    bool? autoMode,
    int? distanceExtended,
    int? distanceRetracted,
    bool? enablePirControl,
    bool? retractOnUserPresent,
    int? pirRetractDelay,
    String? requestedState,
  }) {
    return DeviceConfig(
      tempMinThreshold: tempMinThreshold ?? this.tempMinThreshold,
      tempMaxThreshold: tempMaxThreshold ?? this.tempMaxThreshold,
      humidityMinThreshold: humidityMinThreshold ?? this.humidityMinThreshold,
      humidityMaxThreshold: humidityMaxThreshold ?? this.humidityMaxThreshold,
      motorTimeout: motorTimeout ?? this.motorTimeout,
      sensorReadInterval: sensorReadInterval ?? this.sensorReadInterval,
      useCustomThresholds: useCustomThresholds ?? this.useCustomThresholds,
      autoMode: autoMode ?? this.autoMode,
      distanceExtended: distanceExtended ?? this.distanceExtended,
      distanceRetracted: distanceRetracted ?? this.distanceRetracted,
      enablePirControl: enablePirControl ?? this.enablePirControl,
      retractOnUserPresent: retractOnUserPresent ?? this.retractOnUserPresent,
      pirRetractDelay: pirRetractDelay ?? this.pirRetractDelay,
      requestedState: requestedState ?? this.requestedState,
    );
  }
}

class DeviceModel {
  final String id;
  final String name;
  final String location;
  final String macAddress;
  final DeviceStatus status;
  final SensorData sensorData;
  final DeviceInfo deviceInfo;
  final DeviceConfig deviceConfig;
  final DateTime lastUpdate;
  final bool isOnline;

  const DeviceModel({
    required this.id,
    required this.name,
    required this.location,
    required this.macAddress,
    required this.status,
    required this.sensorData,
    required this.deviceInfo,
    required this.deviceConfig,
    required this.lastUpdate,
    required this.isOnline,
  });

  factory DeviceModel.fromMap(Map<dynamic, dynamic> map, String deviceId) {
    // Get the latest sensor data from logs
    SensorData latestSensorData;
    if (map['sensors']?['logs'] != null) {
      final logs = map['sensors']['logs'] as Map<dynamic, dynamic>;
      if (logs.isNotEmpty) {
        // Get the most recent log entry (sort by timestamp numerically)
        final sortedLogs = logs.entries.toList()
          ..sort((a, b) {
            final aTimestamp = int.tryParse(a.value['timestamp']?.toString() ?? '0') ?? 0;
            final bTimestamp = int.tryParse(b.value['timestamp']?.toString() ?? '0') ?? 0;
            return bTimestamp.compareTo(aTimestamp); // Most recent first
          });
        latestSensorData = SensorData.fromMap(sortedLogs.first.value);
      } else {
        latestSensorData = SensorData.fromMap({});
      }
    } else {
      latestSensorData = SensorData.fromMap({});
    }

    return DeviceModel(
      id: deviceId,
      name: map['info']?['deviceName'] ?? 'Unknown Device',
      location: map['info']?['deviceLocation'] ?? 'Unknown Location',
      macAddress: map['info']?['deviceID'] ?? '',
      status: DeviceStatus.fromString(map['status']?['state'] ?? 'OFFLINE'),
      sensorData: latestSensorData,
      deviceInfo: DeviceInfo.fromMap(map['info'] ?? {}),
      deviceConfig: DeviceConfig.fromMap(map['config'] ?? {}),
      lastUpdate: DateTime.tryParse(map['status']?['timestamp']?.toString() ?? '') ?? DateTime.now(),
      isOnline: map['status']?['motorRunning'] != null, // Device is online if it has status data
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'deviceInfo': deviceInfo.toMap(),
      'deviceConfig': deviceConfig.toMap(),
      'location': location,
      'status': {
        'currentState': status.toString(),
        'lastUpdate': lastUpdate.toIso8601String(),
        'systemHealth': isOnline ? 'OK' : 'ERROR',
        'wifiConnected': isOnline,
      },
      'sensorData': sensorData.toMap(),
    };
  }

  DeviceModel copyWith({
    String? id,
    String? name,
    String? location,
    String? macAddress,
    DeviceStatus? status,
    SensorData? sensorData,
    DeviceInfo? deviceInfo,
    DeviceConfig? deviceConfig,
    DateTime? lastUpdate,
    bool? isOnline,
  }) {
    return DeviceModel(
      id: id ?? this.id,
      name: name ?? this.name,
      location: location ?? this.location,
      macAddress: macAddress ?? this.macAddress,
      status: status ?? this.status,
      sensorData: sensorData ?? this.sensorData,
      deviceInfo: deviceInfo ?? this.deviceInfo,
      deviceConfig: deviceConfig ?? this.deviceConfig,
      lastUpdate: lastUpdate ?? this.lastUpdate,
      isOnline: isOnline ?? this.isOnline,
    );
  }

  @override
  String toString() {
    return 'DeviceModel(id: $id, name: $name, location: $location, status: $status, isOnline: $isOnline)';
  }
}



class DeviceInfo {
  final String deviceName;
  final String location;
  final String macAddress;
  final String ipAddress;
  final DateTime registeredAt;
  final String firmwareVersion;

  DeviceInfo({
    required this.deviceName,
    required this.location,
    required this.macAddress,
    required this.ipAddress,
    required this.registeredAt,
    required this.firmwareVersion,
  });

  factory DeviceInfo.fromMap(Map<dynamic, dynamic> map) {
    return DeviceInfo(
      deviceName: map['deviceName'] ?? 'Unknown Device',
      location: map['deviceLocation'] ?? 'Unknown Location',
      macAddress: map['deviceID'] ?? '',
      ipAddress: '', // Not available in your structure
      registeredAt: DateTime.tryParse(map['lastRegistered']?.toString() ?? '') ?? DateTime.now(),
      firmwareVersion: map['version'] ?? '1.0',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'deviceName': deviceName,
      'location': location,
      'macAddress': macAddress,
      'ipAddress': ipAddress,
      'registeredAt': registeredAt.toIso8601String(),
      'firmwareVersion': firmwareVersion,
    };
  }
}

 