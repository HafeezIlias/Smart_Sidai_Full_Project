enum DeviceStatus {
  extended,
  retracted,
  moving,
  error,
  offline;

  static DeviceStatus fromString(String status) {
    switch (status.toUpperCase()) {
      case 'EXTENDED':
        return DeviceStatus.extended;
      case 'RETRACTED':
        return DeviceStatus.retracted;
      case 'MOVING':
        return DeviceStatus.moving;
      case 'ERROR':
        return DeviceStatus.error;
      default:
        return DeviceStatus.offline;
    }
  }

  @override
  String toString() {
    return name.toUpperCase();
  }

  String get displayName {
    switch (this) {
      case DeviceStatus.extended:
        return 'Extended';
      case DeviceStatus.retracted:
        return 'Retracted';
      case DeviceStatus.moving:
        return 'Moving';
      case DeviceStatus.error:
        return 'Error';
      case DeviceStatus.offline:
        return 'Offline';
    }
  }
} 