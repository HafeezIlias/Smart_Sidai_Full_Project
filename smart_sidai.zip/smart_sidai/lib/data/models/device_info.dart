class DeviceInfo {
  final String deviceName;
  final String location;
  final String macAddress;
  final String ipAddress;
  final DateTime registeredAt;
  final String firmwareVersion;

  const DeviceInfo({
    required this.deviceName,
    required this.location,
    required this.macAddress,
    required this.ipAddress,
    required this.registeredAt,
    required this.firmwareVersion,
  });

  DeviceInfo copyWith({
    String? deviceName,
    String? location,
    String? macAddress,
    String? ipAddress,
    DateTime? registeredAt,
    String? firmwareVersion,
  }) {
    return DeviceInfo(
      deviceName: deviceName ?? this.deviceName,
      location: location ?? this.location,
      macAddress: macAddress ?? this.macAddress,
      ipAddress: ipAddress ?? this.ipAddress,
      registeredAt: registeredAt ?? this.registeredAt,
      firmwareVersion: firmwareVersion ?? this.firmwareVersion,
    );
  }
} 