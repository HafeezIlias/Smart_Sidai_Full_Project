package com.example.smart_sidai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
